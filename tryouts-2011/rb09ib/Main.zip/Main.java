
package testing;

/**
 *
 * @author rb09ib
 */
public class Main {


    public static void main(String[] args) {

        int i,j,k;
        double x,y,z;

        i=3;
        j=5;
        x=3.0;
        y=5.0;

        z= i+ (double)j/3;
        System.out.println(z);
    }

}
