import java.lang.*;
import java.io.*;
import java.math.*;


public class Main {

    public static void main(String args[]) {
       BigInteger N = null;// new BigInteger();
       BigInteger P = null;//new BigInteger();

       try {

       BufferedReader b = new BufferedReader(new InputStreamReader(System.in));
       String line = b.readLine();
       int amountOfInputs = Integer.parseInt(line);

       for(int i = 0; i < amountOfInputs; i++) {
           line = b.readLine();
           N = new BigInteger(line);
           line = b.readLine();
           P = new BigInteger(line);
           BigInteger rem = P.mod(N);
           System.out.println(rem);
       }

       } catch(Exception e) {
          System.err.println(e.getStackTrace());
       }
    }

}
