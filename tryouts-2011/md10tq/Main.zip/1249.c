#include <stdio.h>
#include <math.h>


double getDistance(double ax, double ay, double bx, double by);
int main() {
  double ax = 1, ay, bx, by, cx, cy, dx, dy, ex, ey, fx, fy;

  while( ax!=0 || ay!=0 ||bx!=0 ||by!=0 ||cx!=0 ||cy!=0 ||dx!=0 ||dy!=0|| ex!=0 ||ey !=0 || fx != 0 || fy!=0) {
    scanf("%lf %lf %lf %lf %lf %lf %lf %lf %lf %lf %lf %lf", &ax, &ay, &bx, &by, &cx, &cy, &dx, &dy, &ex, &ey, &fx, &fy);
    if(!( ax!=0 || ay!=0 ||bx!=0 ||by!=0 ||cx!=0 ||cy!=0 ||dx!=0 ||dy!=0|| ex!=0 ||ey !=0 || fx != 0 || fy!=0)) {
      break;
    }

    if(ay == cy) {
       /* vodorovne */
       
       if(ax < cx) {
          /* od a do c */
          printf("here\n");
          double i;
          for(i = -1000.01; i <= 1000.1; i++) {
              double hx = i;
              double ny = (ax-cx);
              double nx = -(ay-cy);
              double nc = -(nx*ax + ny*ay);
              double hy = -(nx/ny)*hx+(nc/nx);/*dopocitat */

              double a = getDistance(cx,cy,bx,by);
              double b = getDistance(ax,ay,cx,cy);
              double c = getDistance(ax,ay,bx,by);
              
              double s = (a+b+c)/2;
              double area = 2*sqrt(s*(s-a)*(s-b)*(s-c));
              
              double d = getDistance(ex,ey,fx,fy);
              double e = getDistance(dx,dy,fx,fy);
              double f = getDistance(dx,dy,ex,ey);
              double ss = (d+e+f)/2;
              double area1 = sqrt(s*(s-d)*(s-e)*(s-f));

              if(abs(area - area1) < 0.0001) {
                  printf("%.3lf %.3lf %.3lf %.3lf\n", cx+(hx-ax), cy+(hy-ay) , hx, hy);
                  break;
              } 
              
          }
       } else {
          /* od c do a */
          printf("here1\n");
          double i;
          for(i = -1000.01; i <= 1000.01; i++) {
              double hx = i;
              double ny = -(ax-cx);
              double nx = (ay-cy);
              double nc = -(nx*ax + ny*ay);
              double hy = -(nx/ny)*hx+(nc/nx);/*dopocitat*/

              double a = getDistance(cx,cy,bx,by);
              double b = getDistance(ax,ay,cx,cy);
              double c = getDistance(ax,ay,bx,by);
              
              double s = (a+b+c)/2;
              double area = 2*sqrt(s*(s-a)*(s-b)*(s-c));
              
              double d = getDistance(ex,ey,fx,fy);
              double e = getDistance(dx,dy,fx,fy);
              double f = getDistance(dx,dy,ex,ey);
              double ss = (d+e+f)/2;
              double area1 = sqrt(s*(s-d)*(s-e)*(s-f));

              if(abs(area - area1) < 0.0001) {
                  printf("%.3lf %.3lf %.3lf %.3lf\n", ax+(hx-cx), ay+(hy-cy), hx, hy);
                  break;
              }
              
          }
       }
    } else {
       /* svisle*/
       
          printf("here3\n");
       if(ay < cy) {
           /* o   d a do c*/
          double i;
          for( i = -1000.01; i <= 1000.01; i++) {
              double hy = i;
              double ny = -(ax-cx);
              double nx = (ay-cy);
              double nc = -(nx*ax + ny*ay);
              double hx = -(nx/ny)*hy+(nc/nx);/*dopocitat*/

              double a = getDistance(cx,cy,bx,by);
              double b = getDistance(ax,ay,cx,cy);
              double c = getDistance(ax,ay,bx,by);
              
              double s = (a+b+c)/2;
              double area = 2*sqrt(s*(s-a)*(s-b)*(s-c));
              
              double d = getDistance(ex,ey,fx,fy);
              double e = getDistance(dx,dy,fx,fy);
              double f = getDistance(dx,dy,ex,ey);
              double ss = (d+e+f)/2;
              double area1 = sqrt(s*(s-d)*(s-e)*(s-f));

              if(abs(area - area1) < 0.0001) {
                  printf("%.3lf %.3lf %.3lf %.3lf\n", cx+(hx-ax), cy+(hy-ay), hx, hy);
                  break;
              }
              
          }
       } else {
          printf("here4\n");
    
           /* od c do a*/
          double i;
          for(i = -1000.01; i <= 1000.01; i++) {
              double hy = i;
              double ny = (ax-cx);
              double nx = -(ay-cy);
              double nc = -(nx*ax + ny*ay);
              double hx = -(nx/ny)*hy+(nc/nx);/*dopocitat*/

              double a = getDistance(cx,cy,bx,by);
              double b = getDistance(ax,ay,cx,cy);
              double c = getDistance(ax,ay,bx,by);
              
              double s = (a+b+c)/2;
              double area = 2*sqrt(s*(s-a)*(s-b)*(s-c));
              
              double d = getDistance(ex,ey,fx,fy);
              double e = getDistance(dx,dy,fx,fy);
              double f = getDistance(dx,dy,ex,ey);
              double ss = (d+e+f)/2;
              double area1 = sqrt(s*(s-d)*(s-e)*(s-f));

              if(abs(area - area1) < 0.0001) {
                  
                  printf("%.3lf %.3lf %.3lf %.3lf\n", ax+(hx-cx), ay+(hy-cy), hx, hy);
                  break;
              }
              
          }
       }

  }
  return 0;
}
}


double getDistance(double ax, double ay, double bx, double by) {
    double x = ax - bx;
    double y = ay - by;
    return (sqrt(x*x + y*y));
}



